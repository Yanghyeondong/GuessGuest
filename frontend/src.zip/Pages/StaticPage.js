import React from 'react';

const StaticPage = () => {
  return (
    <div style={{ backgroundColor: '#FF9999', height: '100vh' }}>
      <h1>StaticPage </h1>
    </div>
  );
};

export default StaticPage;
