import React from 'react';

const MainPage = () => {
  return (
    <div style={{ backgroundColor: '#FF9999', height: '100vh' }}>
      <h1>MainPage </h1>
    </div>
  );
};

export default MainPage;
