import React, { useState } from "react";

const HouseListPage = () => {
  const [sortStateMBTI, setSortStateMBTI] = useState("default");
  const [sortStateSolo, setSortStateSolo] = useState("default");
  const [sortStateGender, setSortStateGender] = useState("default");

  const [guestHouses, setGuestHouses] = useState([
    {
      id: 1,
      name: "소도스 게스트 하우스",
      location: "경기도 양평군",
      description: "게스트들과 즐기는 불멍🔥",
      totalGuests: 10,
      mbtiE: 6,
      mbtiI: 4,
      ageGroups: { "20": 4, "30": 5, "40": 1 },
      soloYes: 7,
      soloNo: 3,
      genderRatio: { 남자: 6, 여자: 4 },
    },
    {
      id: 2,
      name: "힐링 게스트하우스",
      location: "강원도 강릉시",
      description: "바다가 보이는 힐링 숙소 🌊",
      totalGuests: 8,
      mbtiE: 2,
      mbtiI: 6,
      ageGroups: { "20": 2, "30": 3, "40": 3 },
      soloYes: 5,
      soloNo: 3,
      genderRatio: { 남자: 3, 여자: 5 },
    },
  ]);

  // ✅ MBTI 정렬
  const sortByMBTI = () => {
    let sortedList;
    if (sortStateMBTI === "default") {
      sortedList = [...guestHouses].sort((a, b) => b.mbtiE / b.totalGuests - a.mbtiE / a.totalGuests);
      setSortStateMBTI("asc");
    } else if (sortStateMBTI === "asc") {
      sortedList = [...guestHouses].sort((a, b) => a.mbtiE / a.totalGuests - b.mbtiE / b.totalGuests);
      setSortStateMBTI("desc");
    } else {
      sortedList = [...guestHouses].sort((a, b) => a.name.localeCompare(b.name));
      setSortStateMBTI("default");
    }
    setGuestHouses(sortedList);
  };

  // ✅ 솔로 정렬
  const sortBySolo = () => {
    let sortedList;
    if (sortStateSolo === "default") {
      sortedList = [...guestHouses].sort((a, b) => b.soloYes / b.totalGuests - a.soloYes / a.totalGuests);
      setSortStateSolo("asc");
    } else if (sortStateSolo === "asc") {
      sortedList = [...guestHouses].sort((a, b) => a.soloYes / a.totalGuests - b.soloYes / b.totalGuests);
      setSortStateSolo("desc");
    } else {
      sortedList = [...guestHouses].sort((a, b) => a.name.localeCompare(b.name));
      setSortStateSolo("default");
    }
    setGuestHouses(sortedList);
  };

  // ✅ 성비 정렬
  const sortByGender = () => {
    let sortedList;
    if (sortStateGender === "default") {
      sortedList = [...guestHouses].sort((a, b) => b.genderRatio.남자 - a.genderRatio.남자);
      setSortStateGender("asc");
    } else if (sortStateGender === "asc") {
      sortedList = [...guestHouses].sort((a, b) => b.genderRatio.여자 - a.genderRatio.여자);
      setSortStateGender("desc");
    } else {
      sortedList = [...guestHouses].sort((a, b) => a.name.localeCompare(b.name));
      setSortStateGender("default");
    }
    setGuestHouses(sortedList);
  };

  return (
    <div style={styles.mainContainer}>
      <h2 style={styles.sectionTitle}>Guess Your Place</h2>

      <div style={styles.wrapperBox}>
        {/* 필터 버튼 */}
        <div style={styles.filterContainer}>
          <button style={styles.filterButton}>관광명소</button>
          <button style={styles.filterButton} onClick={sortByMBTI}>
            {sortStateMBTI === "asc" ? "MBTI E↑" : sortStateMBTI === "desc" ? "MBTI E↓" : "MBTI"}
          </button>
          <button style={styles.filterButton}>연령대</button>
          <button style={styles.filterButton} onClick={sortBySolo}>
            {sortStateSolo === "asc" ? "솔로 ↑" : sortStateSolo === "desc" ? "솔로 ↓" : "솔로"}
          </button>
          <button style={styles.filterButton} onClick={sortByGender}>
            {sortStateGender === "asc" ? "남자 ↑" : sortStateGender === "desc" ? "여자 ↑" : "성비"}
          </button>
        </div>

        <div style={styles.listContainer}>
          {guestHouses.map((house) => (
            <div key={house.id} style={styles.guestHouseBox}>
              <div style={styles.infoContainer}>
                <div style={styles.imagePlaceholder}></div>

                <div style={styles.textInfo}>
                  <h3>{house.name}</h3>
                  <p>{house.location}</p>
                  <p>"{house.description}"</p>
                </div>

                <div style={styles.buttonContainer}>
                  <button style={styles.actionButton}>숙소보기</button>
                  <button style={styles.actionButton}>게스트보기</button>
                </div>
              </div>

              <div style={styles.statsGrid}>
                <div>MBTI: {((house.mbtiE / house.totalGuests) * 100).toFixed(1)}%</div>
                <div>연령대: {Object.keys(house.ageGroups).reduce((a, b) => (house.ageGroups[a] > house.ageGroups[b] ? a : b))}대</div>
                <div>솔로: {((house.soloYes / house.totalGuests) * 100).toFixed(1)}%</div>
                <div>성비: 남 {house.genderRatio.남자} / 여 {house.genderRatio.여자}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const styles = {
  mainContainer: { display: "flex", flexDirection: "column", alignItems: "center", backgroundColor: "#ff9ea6", minHeight: "100vh", padding: "40px" },
  sectionTitle: { color: "#FFFFFF", fontWeight: "bold", fontSize: "24px", marginBottom: "20px" },
  wrapperBox: { background: "#fff", width: "80%", padding: "20px", borderRadius: "15px", boxShadow: "0px 4px 8px rgba(0,0,0,0.1)" },
  filterContainer: { display: "flex", justifyContent: "center", gap: "10px", marginBottom: "20px" },
  filterButton: { padding: "8px 16px", border: "none", borderRadius: "5px", background: "#fff", cursor: "pointer", fontWeight: "bold", boxShadow: "0px 2px 4px rgba(0,0,0,0.1)" },
  listContainer: { maxHeight: "400px", overflowY: "auto", display: "flex", flexDirection: "column", gap: "15px" },
  guestHouseBox: { background: "#FFECEC", padding: "15px", borderRadius: "10px", display: "flex", flexDirection: "column", alignItems: "center" },
  infoContainer: { display: "flex", alignItems: "center", justifyContent: "space-between", width: "90%" },
  imagePlaceholder: { width: "50px", height: "50px", borderRadius: "50%", backgroundColor: "#ccc" },
  textInfo: { textAlign: "center", flex: 1 },
  buttonContainer: { display: "flex", flexDirection: "column", gap: "5px" },
  actionButton: { padding: "8px 16px", border: "1px solid #ccc", borderRadius: "5px", cursor: "pointer" },
  statsGrid: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px", width: "60%", textAlign: "center", marginTop: "10px" },
};

export default HouseListPage;